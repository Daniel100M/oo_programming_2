import org.junit.jupiter.api.Test;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;

import java.util.concurrent.*;

import static org.junit.Assert.assertEquals;


class Task_CustomExecutor_Test {

    @Test
    /** in this test method i had to "throws Exception" because the task.call() func
     *  can return an exception! */
    void CreateTask2param_Test1()  {
        Task task = Task.createTask(()->{
            int sum = 0;
            for (int i = 1; i <= 10; i++) {
                sum += i;
            }
            return sum;
        }, TaskType.COMPUTATIONAL);

        try {
            assertEquals(55, task.call());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void CreateTask1param() {
        Callable<String> callable = ()->{
            StringBuilder sb = new StringBuilder("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
            return sb.reverse().toString();
        };
        Task task2 = Task.createTask(callable);
        try{
            assertEquals("ZYXWVUTSRQPONMLKJIHGFEDCBA",task2.call());
        }catch (Exception e){
            throw new RuntimeException();
        }
    }

    @Test
    void CustomExe_Test1_modified(){
        CustomExecutor customExecutor = new CustomExecutor();
        Task<Integer> task = Task.createTask(()->{
            int sum = 0;
            for(int i=1; i<=10; i++)
                sum+=i;
            return sum;
        },TaskType.COMPUTATIONAL);

        Future<Integer> sumTask = customExecutor.submbit(task);
        final int sum;
        try{
            sum = sumTask.get(1, TimeUnit.MILLISECONDS);
        }catch (Exception e){
            throw new RuntimeException();
        }
        assertEquals(55,sum);
    }

    @Test
    void CustomExe_Test2_modified(){
        CustomExecutor customExecutor = new CustomExecutor();
        Callable<Double> callable1 = ()->{
            return 1000*Math.pow(1.02,5);
        };
        var doubleFuture = customExecutor.submit(callable1);
        final double doubleNumber;
        try{
            doubleNumber = doubleFuture.get();
        }catch (Exception e){
            throw new RuntimeException(e);
        }
        assertEquals(1104.080803,doubleNumber,0.000001);
    }

    @Test
    void CustomExe_Test3_modified(){
        CustomExecutor customExecutor = new CustomExecutor();
        Callable<String> callable2 = ()->{
            StringBuilder sb = new StringBuilder("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
            return sb.reverse().toString();
        };
        var stringTask = customExecutor.submit(callable2,TaskType.COMPUTATIONAL);
        final String reveredString;
        try{
            reveredString = stringTask.get();
        }catch (Exception e){
            throw new RuntimeException();
        }

        assertEquals("ZYXWVUTSRQPONMLKJIHGFEDCBA", reveredString );
    }

}