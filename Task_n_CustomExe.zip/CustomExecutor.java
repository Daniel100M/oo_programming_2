import java.util.concurrent.ThreadPoolExecutor;
import java.util.PriorityQueue;
import java.util.concurrent.*;
public class CustomExecutor extends ThreadPoolExecutor {
    private static int numOfCores = Runtime.getRuntime().availableProcessors();
    private int[] priorityCounter = {0,0,0,0,0,0,0,0,0,0};

    public CustomExecutor(){
        super(numOfCores/2,numOfCores-1,300,TimeUnit.MILLISECONDS,new PriorityBlockingQueue<>());
    }
        //
    public <V> Future<V> submit(Task<V> realTask){
        if(realTask == null || realTask.getCallable() == null)
            throw new NullPointerException();
        execute(realTask);
        priorityCounter[realTask.getTaskType().getPriorityValue()-1]++;
        return realTask;
    }

    public <V> Future<V> submit(Callable<V> realTask, TaskType taskType){
        Task<V> task = Task.createTask(realTask,taskType);
        submit(task);
        return task;
    }

    public <V> Future<V> submbit(Callable<V> realTask){
        Task<V> task = Task.createTask(realTask);
        submit(task);
        return task;
    }
    @Override
    protected void beforeExecute(Thread t, Runnable r) {
        int priority = getCurrentMax();
        if(1<=priority && priority<=10)
            priorityCounter[priority-1]--;
    }

//    @Override
//    public Future<?> submit(Runnable task) {
//        return null;
//    }

    public int getCurrentMax(){
        for(int i =0; i<10;i++){
            if(priorityCounter[i] != 0)
                return i+1;
        }
        return -1;
    }

    public void gracefullyTerminate(){
        try{
            super.awaitTermination(300,TimeUnit.MILLISECONDS);
            super.shutdown();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println(e.getCause());
        }
    }
}




//    public class CustomExecutor extends ThreadPoolExecutor {
//        public CustomExecutor() {
//            super(Runtime.getRuntime().availableProcessors()/2, Runtime.getRuntime().availableProcessors() - 1, 300, TimeUnit.MILLISECONDS, new PriorityBlockingQueue<Runnable>());
//        }
//        public void submit(Callable task, TaskType taskType) {
//            this.submit(task);
//        }
//        public int getCurrentMax(){
//            return -1;
//        }
//        public void gracefullyTerminate(){}
//    }
