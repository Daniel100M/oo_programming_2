import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

public class Task<V> extends FutureTask<V> implements Comparable<Task>, Callable<V> {
    private TaskType taskType;
    private Callable<V> realTask;

    private Task(Callable<V> callable, TaskType taskType) {
        super(callable);
        this.realTask = callable;
        this.taskType = taskType;
    }
    private Task(Callable<V> callable) {
        this(callable,TaskType.OTHER);
    }

    public static Task createTask(Callable realTask,TaskType taskType){
        return new Task(realTask,taskType);
    }
    public static Task createTask(Callable realTask){
        return new Task(realTask);
    }

    @Override
    public int compareTo(Task other) {
        if(other.taskType.getPriorityValue() < this.taskType.getPriorityValue())
            return -1;
        if(other.taskType.getPriorityValue() > this.taskType.getPriorityValue())
            return 1;
        return 0;
    }
    @Override
    public V call() throws Exception{
        return this.realTask.call();
    }

    public Callable<V> getCallable(){
        return this.realTask;
    }

    public TaskType getTaskType(){
        return this.taskType;
    }
    public void setTaskType(TaskType taskType){
        this.taskType = taskType;
    }

}
